#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# ATS CV Pro – Auto-rename script
# Run this from the ROOT of your cloned fork:
#   chmod +x rename-to-ats-cv-pro.sh
#   ./rename-to-ats-cv-pro.sh
#
# What it does:
#   1. Renames all occurrences of "OpenResume" → "ATS CV Pro" in source files
#   2. Updates package.json name field
#   3. Copies the new subscription page and updated TopNavBar into place
# ─────────────────────────────────────────────────────────────────────────────

set -e

echo "🔄 Renaming OpenResume → ATS CV Pro across source files..."

# ── Text replacements in .tsx / .ts / .js / .json / .md files ──────────────
find src -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.js" \) | while read file; do
  sed -i \
    -e 's/OpenResume/ATS CV Pro/g' \
    -e 's/open-resume/ats-cv-pro/g' \
    -e 's/open resume/ATS CV Pro/g' \
    "$file"
  echo "  ✅ $file"
done

# ── Update package.json name ─────────────────────────────────────────────────
if [ -f package.json ]; then
  sed -i 's/"name": "open-resume"/"name": "ats-cv-pro"/' package.json
  echo "  ✅ package.json"
fi

echo ""
echo "📋 Now copy these files from the ats-cv-pro-changes folder:"
echo "   → src/app/components/TopNavBar.tsx   (rebranded nav)"
echo "   → src/app/subscription/page.tsx      (Razorpay pricing page)"
echo "   → src/app/layout.tsx                 (updated metadata)"
echo ""
echo "🔑 Add to Vercel env vars:"
echo "   NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_live_xxxx"
echo ""
echo "✅ Done! Commit and push to trigger Vercel deploy."
